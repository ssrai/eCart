import "./App.css";
import Header from "./components/Header";
import Products from "./components/Products";
import React, { useState } from "react";

function App() {
  const [products, setProducts] = useState([
    {
      product_id: 1,
      product_name: "T-shirt",
      product_price: 18.0,
      totalStock: 485,
    },
    {
      product_id: 2,
      product_name: "Beanie",
      product_price: 20.0,
      totalStock: 489,
    },
    {
      product_id: 3,
      product_name: "Sunglasses",
      product_price: 90.0,
      totalStock: 490,
    },
    {
      product_id: 4,
      product_name: "Belt",
      product_price: 55.0,
      totalStock: 492,
    },
    {
      product_id: 5,
      product_name: "Cap",
      product_price: 16.0,
      totalStock: 490,
    },
  ]);

  return (
    <>
      <div className="App">
        <header>
          <Header />
        </header>
      </div>
      <div>
        <Products allProducts={products} />
      </div>
    </>
  );
}

export default App;
