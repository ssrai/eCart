import React from "react";
import Product from "./Product";

export default function Products(props) {
  return (
    <>
      <div className="container-fluid my-2">
        <a disabled={true} className="navbar-brand" href="#">
          Products
        </a>
      </div>
      <nav className="navbar navbar-dark bg-light my-2">
        <div className="container-fluid">
          <form className="d-flex">
            <input
              className="form-control me-2"
              type="search"
              placeholder="Search Product..."
              aria-label="Search"
            />
            <button className="btn btn-outline-success " type="submit">
              Search
            </button>
          </form>
          <h4>{props.allProducts.length} results</h4>
        </div>
      </nav>

      {props.allProducts.length === 0 && (
        <p>Please add Product to get item listed below!</p>
      )}
      <div className="row container-fluid">
        {props.allProducts.map((product) => (
          <Product key={product.product_id} product={product} />
        ))}
      </div>
    </>
  );
}
