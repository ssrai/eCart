import React from "react";

export default function Product(props) {
  return (
    <>
      <div className="card my-2 mx-2">
        <div className="card-body">
          <h5 className="card-title">
            Product Name: {props.product.product_name}
          </h5>
          <h6 className="card-subtitle mb-2 text-muted">
            Product Price: $ <a href="#">{props.product.product_price}</a>
          </h6>
          <p className="card-text">
            Available Stock: {props.product.totalStock}
          </p>
        </div>
      </div>
    </>
  );
}
